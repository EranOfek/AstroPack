This package contains the following files:

1) dcraw.exe (32-bit version)
2) dcraw64.exe (64-bit version)
3) dcraw.c (source code by Dave Coffin, http://www.cybercom.net/~dcoffin/dcraw/)
4) readme.txt (this file)

dcraw.c was compiled with full optimization (using the Microsoft C/C++ optimizing compiler). The two executables are digitally signed.

Brought to you by http://www.fastpictureviewer.com, home of the best RAW codecs for Windows and the quickest image viewer for photo culling.