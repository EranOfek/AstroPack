All examples are using uos_flat.

uos_flat is a over-layer for uos that takes care about class declarations.
You do not have to declare anything in your main application.
All procedures have a "universal procedurial" syntax.

If you prefer to use uos directly, SimplePlayer_noflat shows how to do.
This way all procedures can be used as oop. (java flavour).


