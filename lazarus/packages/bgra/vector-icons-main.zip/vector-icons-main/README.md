# vector-icons
LazPaint vector icons
