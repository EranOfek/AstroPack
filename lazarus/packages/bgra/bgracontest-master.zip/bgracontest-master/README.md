# bgracontest
Participations of the BGRABitmap Graphic Contest 2015 and Participations of the Graphics Contest 2016