from lazpaint import colors, image

#image.flatten()
#colors.curves(red=[(0, 0), (0.25, 1), (1, 1)])
#colors.curves(lightness=[(0, 0), (0.25, 1), (1, 1)])
#colors.posterize(levels=8, by_lightness=True)
#colors.colorize(hue_angle=180, saturation=0.8, correction=False)
colors.lightness(-1, 0)
#colors.complementary()
#colors.shift(hue_angle=90, saturation=0, correction=True)

