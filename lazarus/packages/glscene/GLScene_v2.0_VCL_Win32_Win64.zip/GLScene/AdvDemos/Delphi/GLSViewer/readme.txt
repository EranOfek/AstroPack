GLSViewer

http://sourceforge.net/projects/glscene
http://glscene.org

A fast 3D mesh viewer. 
Released as Freeware and open-sourced
under Mozilla PL (http://mozilla.org)

3D Formats: 3DS, OBJ, SMD, MD2, TIN, PLY, STL etc.
2D Formats: JPG, BMP, TGA, CEL etc.

Supports smooth and flat shading, wireframes,
hidden lines removal, texturing and antialiasing
(if supported by hardware).

GLSViewer was made and packaged with the following
tools and libraries:

- RAD Studio (http://edn.embarcadero.com/delphi/)
- GLScene (http://glscene.net; http://sf.net/projects/glscene)

Enjoy.

GLS Team