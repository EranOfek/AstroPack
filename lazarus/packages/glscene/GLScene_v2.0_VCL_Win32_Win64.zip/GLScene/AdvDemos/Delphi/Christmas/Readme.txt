GLScene Christmas 2015 
based on 2002 "ScreenSaver" by Eric Grange

The scene is made up from a few meshes, some GLScene objects, several
lens-flares and particle effects components, and a 2 text. BASS is used
for the sound part (3D positionned fire loop, and mp3 playback).
Wrapped gifts appear around christmas every year.

Assembled from bits from the web, should be royalty free, but I don't have
the means to check... so if you have clues about any of them:
- Models: from 3DCafe.com, some were altered
- Textures: various origins, some from 3dtextures.fr.st, others made by me
- Music: unknown origin, was in a "royalty free" download package,
  playback via BASS (http://www.un4seen.com/music/)

Customized using GLScene v.1.3 for Delphi & C++Builder 
Adapted for Happy New Year with PopupMenu items. 
Sound library BASS 2.4.10 as bass.dll included.
Copyright (c) 1999-2014 Un4seen Developments Ltd. All rights reserved.
Check http://www.un4seen.com/music/ for any later bass.dll

Updated Christmas source available from the GLScene Sourceforge site (AdvDemos) at
http://sourceforge.net/projects/glscene

GLS Team


