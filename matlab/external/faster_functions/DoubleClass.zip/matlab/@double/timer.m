%t=timer
%-------
%
%Read the timestamp counter of Pentium processors.
%
%        Marcel Leutenegger � 20.6.2004
%
%Output:
% t      Elapsed processor clocks since last call
%