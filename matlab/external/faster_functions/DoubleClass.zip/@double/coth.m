function y=coth(x)
y=1./tanh(x);  % use fast tangens hyperbolicus
