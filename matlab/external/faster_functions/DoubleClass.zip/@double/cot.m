function y=cot(x)
y=1./tan(x);   % use fast tangens
