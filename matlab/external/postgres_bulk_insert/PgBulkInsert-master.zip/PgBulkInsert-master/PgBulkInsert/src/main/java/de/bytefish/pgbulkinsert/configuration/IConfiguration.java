// Licensed under the MIT license. See LICENSE file in the project root for full license information.

package de.bytefish.pgbulkinsert.configuration;

public interface IConfiguration {

    int getBufferSize();

}
