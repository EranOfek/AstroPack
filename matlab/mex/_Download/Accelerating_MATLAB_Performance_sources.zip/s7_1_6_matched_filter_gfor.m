%% �7.1.6 - version of the matched filter function using Jacket gfor loops
function data = matched_filter_gfor(data)

    % define speed of light
    c = 299792458;

    % determine the size of the phase history data
    K  = size(data.phdata,1);  % number of frequency bins per pulse
    Np = size(data.phdata,2);  % number of pulses

    % initialize the image with all zero values (on the GPU)
    data.im_final = gzeros(size(data.x_mat), 'double');

    % array to keep "slices" of an image for different frequencies
    im_slices = gzeros([K, size(data.x_mat)], 'double');

    % loop through every pulse
    for ii = 1 : Np
        % Calculate differential range for each image pixel (m)
        dR = sqrt((data.AntX(ii)-data.x_mat).^2 + ...
                  (data.AntY(ii)-data.y_mat).^2 + ...
                  (data.AntZ(ii)-data.z_mat).^2) - data.R0(ii);

        % Calculate the frequency of each sample in the pulse (Hz)
        freq = data.minF(ii) + gdouble(0:(K-1)) * data.deltaF;

        % Perform the Matched Filter operation
        gfor jj = 1 : K  % parallel for loop on the GPU
            im_slices(jj,:,:) = data.phdata(jj,ii) * ...
                                exp(1i*4*pi*freq(jj)/c*dR);
        gend

        % accumulate image data for different frequencies
        data.im_final = data.im_final + squeeze(sum(im_slices,1));
    end  % for ii = 1:Np
    gsync('all');  % ensure all computations on the GPU are done

end  % matched_filter_gfor
