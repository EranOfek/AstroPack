%% HDL Compatible, piplined 2D filter (by Igal@Systematics.co.il)
% function out_pix =  ML_2D_HDL_filt (in_pix, fr_width)
function out_pix =  ML_2D_HDL_filt_floating (in_pix)
    fr_width = 720;
    % Serialized 2D filter

    persistent pix_delay5;
    if isempty(pix_delay5)
        pix_delay5 = dsp.Delay('FrameBasedProcessing', false);
    end

    conv_pix =  form_matrix(in_pix, fr_width); % Compute convolution of serialized image data with sobel masks
    out_pix = step(pix_delay5, conv_pix);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute convolution of serialized image data with sobel masks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function conv_pix =  form_matrix(u, Col)
    % Line Buffers
    persistent line_fifo1 line_fifo2 line_fifo3 line_fifo4;
    if isempty(line_fifo1)
        line_fifo1 = dsp.Delay('FrameBasedProcessing', false, 'Length', Col);
        line_fifo2 = dsp.Delay('FrameBasedProcessing', false, 'Length', Col);
        line_fifo3 = dsp.Delay('FrameBasedProcessing', false, 'Length', Col);
        line_fifo4 = dsp.Delay('FrameBasedProcessing', false, 'Length', Col);
    end

    % Pixel Buffers
    persistent pix_delay1  pix_delay2  pix_delay3  pix_delay4;
    persistent pix_delay11 pix_delay12 pix_delay13 pix_delay14;
    persistent pix_delay21 pix_delay22 pix_delay23 pix_delay24;
    persistent pix_delay31 pix_delay32 pix_delay33 pix_delay34;
    persistent pix_delay41 pix_delay42 pix_delay43 pix_delay44;
    if isempty(pix_delay1)
        pix_delay1 = dsp.Delay('FrameBasedProcessing', false);  pix_delay2 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay3 = dsp.Delay('FrameBasedProcessing', false);  pix_delay4 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay11 = dsp.Delay('FrameBasedProcessing', false); pix_delay12 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay13 = dsp.Delay('FrameBasedProcessing', false); pix_delay14 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay21 = dsp.Delay('FrameBasedProcessing', false); pix_delay22 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay23 = dsp.Delay('FrameBasedProcessing', false); pix_delay24 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay31 = dsp.Delay('FrameBasedProcessing', false); pix_delay32 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay33 = dsp.Delay('FrameBasedProcessing', false); pix_delay34 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay41 = dsp.Delay('FrameBasedProcessing', false); pix_delay42 = dsp.Delay('FrameBasedProcessing', false);
        pix_delay43 = dsp.Delay('FrameBasedProcessing', false); pix_delay44 = dsp.Delay('FrameBasedProcessing', false);
    end

    lb1 = step(line_fifo1, u);     % Column long fifo @t=n: [u(n), u(n-1)...u(n-fr_width+1)] --> lb1 = u(n-fr_width)
    lb2 = step(line_fifo2, lb1);   % Column long fifo @t=n: [u(n-fr_width), u(n-fr_width-1)...u(n-2*fr_width+1)) --> lb2 = u(n-2*fr_width)
    lb3 = step(line_fifo3, lb2);   % Column long fifo @t=n: [u(n-fr_width), u(n-fr_width-1)...u(n-2*fr_width+1)) --> lb3 = u(n-3*fr_width)
    lb4 = step(line_fifo4, lb3);   % Column long fifo @t=n: [u(n-fr_width), u(n-fr_width-1)...u(n-2*fr_width+1)) --> lb4 = u(n-4*fr_width)

    ud1 = step(pix_delay1, u);          % 1/Z              @t=n:  ud1 = u(n-1)
    ud2 = step(pix_delay2, ud1);        % 1/Z              @t=n:  ud2 = u(n-2)
    ud3 = step(pix_delay3, ud2);        % 1/Z              @t=n:  ud3 = u(n-3)
    ud4 = step(pix_delay4, ud3);        % 1/Z              @t=n:  ud4 = u(n-4)

    lb1d1 = step(pix_delay11, lb1);     % 1/Z for fifo out @t=n:  lb1d1 = u[n-fr_width-1]
    lb1d2 = step(pix_delay12, lb1d1);   % 1/Z for fifo out @t=n:  lb1d2 = u[n-fr_width-2]
    lb1d3 = step(pix_delay13, lb1d2);   % 1/Z for fifo out @t=n:  lb1d1 = u[n-fr_width-3]
    lb1d4 = step(pix_delay14, lb1d3);   % 1/Z for fifo out @t=n:  lb1d2 = u[n-fr_width-4]

    lb2d1 = step(pix_delay21, lb2);     % 1/Z for fifo out @t=n:  lb2d1 = u[n-2*fr_width-1]
    lb2d2 = step(pix_delay22, lb2d1);   % 1/Z for fifo out @t=n:  lb2d2 = u[n-2*fr_width-2]
    lb2d3 = step(pix_delay23, lb2d2);   % 1/Z for fifo out @t=n:  lb2d1 = u[n-2*fr_width-3]
    lb2d4 = step(pix_delay24, lb2d3);   % 1/Z for fifo out @t=n:  lb2d1 = u[n-2*fr_width-4]

    lb3d1 = step(pix_delay31, lb3);     % 1/Z for fifo out @t=n:  lb2d1 = u[n-3*fr_width-1]
    lb3d2 = step(pix_delay32, lb3d1);   % 1/Z for fifo out @t=n:  lb2d2 = u[n-3*fr_width-2]
    lb3d3 = step(pix_delay33, lb3d2);   % 1/Z for fifo out @t=n:  lb2d2 = u[n-3*fr_width-3]
    lb3d4 = step(pix_delay34, lb3d3);   % 1/Z for fifo out @t=n:  lb2d2 = u[n-3*fr_width-4]

    lb4d1 = step(pix_delay41, lb4);     % 1/Z for fifo out @t=n:  lb2d1 = u[n-4*fr_width-1]
    lb4d2 = step(pix_delay42, lb4d1);   % 1/Z for fifo out @t=n:  lb2d2 = u[n-4*fr_width-2]
    lb4d3 = step(pix_delay43, lb4d2);   % 1/Z for fifo out @t=n:  lb2d2 = u[n-4*fr_width-3]
    lb4d4 = step(pix_delay44, lb4d3);   % 1/Z for fifo out @t=n:  lb2d2 = u[n-4*fr_width-4]

    conv_pix = twoDconv([u, ud1, ud2, ud3, ud4;...
                         lb1, lb1d1, lb1d2, lb1d3, lb1d4;...
                         lb2, lb2d1, lb2d2, lb2d3, lb2d4;...
                         lb3, lb3d1, lb3d2, lb3d3, lb3d4;...
                         lb4, lb4d1, lb4d2, lb4d3, lb4d4]);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2D Convolution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function conv_pix = twoDconv(pix_mat)
    conv_pix = uint8(0);
    filt_kern = [ 3.1943    6.7623    8.6829    6.7623    3.1943; ...
                  6.7623   14.3158   18.3818   14.3158    6.7623; ...
                  8.6829   18.3818   23.6027   18.3818    8.6829; ...
                  6.7623   14.3158   18.3818   14.3158    6.7623; ...
                  3.1943    6.7623    8.6829    6.7623    3.1943]/256; % normalized

    % Implicit addressing
    conv_pix = uint8(sum(sum(pix_mat .* filt_kern)));

    % Note to myself:
    % In max speed config this multiplication takes 25 (8 bit) multipliers for the convolution calculation and 75 (32 bit) multipliers for address calculation, required clock rate is ~666KHz
    % In min footprint conf this multiplication takes 1 (8 bit) multiplier for the convolution and 3 multipliers for the address, required clock is ~16MHz (still within possible parameters)
    % This is because of the polymorphism of the matrix multiplication. If I use explicit addressing those 32 bit multipliers will be redundunt, but then I can't use the automatic streaming feature!

    % Explicit addressing
    % conv_line1 = sum([pix_mat(1,1) * gauss_kern(1,1)  pix_mat(1,2) * gauss_kern(1,2)  pix_mat(1,3) * gauss_kern(1,3)  pix_mat(1,4) * gauss_kern(1,4)  pix_mat(1,5) * gauss_kern(1,5)]);
    % conv_line2 = sum([pix_mat(2,1) * gauss_kern(2,1)  pix_mat(2,2) * gauss_kern(2,2)  pix_mat(2,3) * gauss_kern(2,3)  pix_mat(2,4) * gauss_kern(2,4)  pix_mat(2,5) * gauss_kern(2,5)]);
    % conv_line3 = sum([pix_mat(3,1) * gauss_kern(3,1)  pix_mat(3,2) * gauss_kern(3,2)  pix_mat(3,3) * gauss_kern(3,3)  pix_mat(3,4) * gauss_kern(3,4)  pix_mat(3,5) * gauss_kern(3,5)]);
    % conv_line4 = sum([pix_mat(4,1) * gauss_kern(4,1)  pix_mat(4,2) * gauss_kern(4,2)  pix_mat(4,3) * gauss_kern(4,3)  pix_mat(4,4) * gauss_kern(4,4)  pix_mat(4,5) * gauss_kern(4,5)]);
    % conv_line5 = sum([pix_mat(5,1) * gauss_kern(5,1)  pix_mat(5,2) * gauss_kern(5,2)  pix_mat(5,3) * gauss_kern(5,3)  pix_mat(5,4) * gauss_kern(5,4)  pix_mat(5,5) * gauss_kern(5,5)]);
    % conv_pix = uint8(sum([conv_line1 conv_line2 conv_line3 conv_line4 conv_line5]));
end