%% Video processing filter Harness (by Igal@Systematics.co.il)

OPmode = 'Behavioral' % 'Behavioral', 'Beh_detailed', 'Bit&Cycle', 'Mex', 'Cosim', 'sampFIL', 'framFIL'

warning('off','fixed:incompatibility:fi:integerDataTypeOperations');

nFrames = 1; % total frames = 249

filt_kern = ([ 3.1943    6.7623    8.6829    6.7623    3.1943; ...
               6.7623   14.3158   18.3818   14.3158    6.7623; ...
               8.6829   18.3818   23.6027   18.3818    8.6829; ...
               6.7623   14.3158   18.3818   14.3158    6.7623; ...
               3.1943    6.7623    8.6829    6.7623    3.1943]/256); % normalized

hVid      = VideoReader('Noisy_Ten_Sec_Timer.avi'); %VideoReader('Ariel.wmv')
vidHeight = uint16(hVid.Height);
vidWidth  = uint16(hVid.Width);

% Preallocate movie structure.
in_frame  = zeros(vidHeight, vidWidth, 'uint8');
out_frame = zeros(vidHeight, vidWidth, 'uint8');
tic
for k = 0 : nFrames-1 %read video frames
    frame = mod(k,249)+1;
    in_frame = rgb2gray(read(hVid, frame));
    
    switch OPmode
        case 'Behavioral' % Behavioral ~0.10 (multiframe)  to 0.30 (singleframe) sec per frame
            out_frame = conv2(double(in_frame), filt_kern, 'same');
            
        case 'Beh_detailed' % Bit&Cycle accurate ~2400sec (~40min) per frame
            for hind = 1:vidWidth %note that the algorithm runs column-major (and not row)
                line = hind;
                for vind = 1:vidHeight
                    out_frame(vind, hind) =  ML_2D_HDL_filt_floating (in_frame(vind, hind));
                    %                     in_pix = in_frame(vind, hind);
                    %                     out_pix =  ML_2D_HDL_filt (in_pix);
                    %                     out_frame(vind, hind) = out_pix;
                end
            end
            
        case 'Bit&Cycle' % Bit&Cycle accurate ~2400sec (~40min) per frame
            for hind = 1:vidWidth %note that the algorithm runs column-major (and not row)
                line = hind;
                for vind = 1:vidHeight
                    out_frame(vind, hind) =  ML_2D_HDL_filt (in_frame(vind, hind));
                    %                     in_pix = in_frame(vind, hind);
                    %                     out_pix =  ML_2D_HDL_filt (in_pix);
                    %                     out_frame(vind, hind) = out_pix;
                end
            end
            
        case 'Mex' % MEX Bit&Cycle accurate <15sec per frame
            for hind = 1:vidWidth %note that the algorithm runs column-major (and not row)
                line = hind;
                for vind = 1:vidHeight
                    out_frame(vind, hind) =  ML_2D_HDL_filt_mex (in_frame(vind, hind));
                    %                     in_pix = in_frame(vind, hind);
                    %                     out_pix =  ML_2D_HDL_filt_mex_Ariel (in_pix);
                    %                     out_pix =  ML_2D_HDL_filt_mex (in_pix);
                    %                     out_frame(vind, hind) = out_pix;
                end
            end
            
        case 'Cosim' % Logic Cosimulation ~150-250sec per frame
            cosim_obj = hdlcosim('InputSignals', {'/ml_2d_hdl_filt_fixpt/clk_enable','/ml_2d_hdl_filt_fixpt/in_pix'}, ...
                'OutputSignals', {'/ml_2d_hdl_filt_fixpt/ce_out','/ml_2d_hdl_filt_fixpt/out_pix'}, ...
                'OutputSigned', [false,false], ...
                'OutputFractionLengths', [0,0], ...
                'TCLPreSimulationCommand', 'force /ml_2d_hdl_filt_fixpt/clk 0 0 ns, 1 5 ns -repeat 10 ns; force /ml_2d_hdl_filt_fixpt/reset 1 0 ns, 0 2 ns; ', ...
                'TCLPostSimulationCommand', 'noforce /ml_2d_hdl_filt_fixpt/clk; noforce /ml_2d_hdl_filt_fixpt/reset; puts "done"; ', ...
                'PreRunTime', {10,'ns'}, ...
                'Connection', {'Shared'}, ...
                'SampleTime', {10,'ns'});
            
            tclcmd = { ...
                'cd C:/Users/igal/Documents/MATLAB/My_Demos/HDL_IMG_2D_FILT/codegen/ML_2D_HDL_filt/hdlsrc;'...
                'vsimmatlabsysobj ml_2d_hdl_filt_fixpt;', ...
                'add wave *;' ...
                };
            
            vsim('tclstart',tclcmd);
            pingHdlSim(20);
            
            for hind = 1:vidWidth %note that the algorithm runs column-major (and not row)
                %                 line = hind
                for vind = 1:vidHeight
                    [~, out_frame(vind, hind)] = step(cosim_obj, true, in_frame(vind, hind));
                    %                     in_pix = in_frame(vind, hind);
                    %                     [~, out_pix] = step(cosim_obj, true, in_pix);
                    %                     out_frame(vind, hind) = out_pix;
                end
            end
            
            clear cosim_obj; % alternative: clear cosim_obj,
            
        case 'sampFIL' % sample-based FIL ~16min per frame
            % addpath('C:\Users\igal\Documents\MATLAB\My_Demos\HDL_IMG_2D_FILT\codegen\ML_2D_HDL_filt\hdlsrc');
            %             MYFIL = ML_2D_HDL_filt_fixpt_fil
            % programFPGA(MYFIL)
            for hind = 1:vidWidth %note that the algorithm runs column-major (and not row)
                %                 line = hind
                for vind = 1:vidHeight
                    [~, out_frame(vind, hind)] = step(MYFIL,in_frame(vind, hind)); % Sampled
                    %                     in_pix = in_frame(vind, hind);
                    %                     [~, out_frame(vind, hind)] = step(MYFIL,in_pix); % Sampled
                    %                     out_frame(vind, hind) = out_pix;
                end
            end
            release(MYFIL);
            
        case 'framFIL' % frame-based FIL 0.5-1.5 sec per frame
            %%             addpath('C:\Users\igal\Documents\MATLAB\My_Demos\HDL_IMG_2D_FILT\codegen\ML_2D_HDL_filt\hdlsrc');
            % addpath('C:\Users\igal\Documents\MATLAB\My_Demos\HDL_IMG_2D_FILT\codegen\ML_2D_HDL_filt\fil');
            %%             MYFIL = ML_2D_HDL_filt_fixpt_fil
            % MYFIL = class_ML_2D_HDL_filt_fixpt_sysobj;
            %             programFPGA(MYFIL)
            %             out_pix_vect = uint8(reshape(step(MYFIL,in_frame(:)),size(in_frame))); % Vectorized
            [~, out_pix_vect] = step(MYFIL,in_frame(:)); % Vectorized
            % in_pix_vect = in_frame(:);
            %             [~, out_pix_vect] = step(MYFIL,in_pix_vect); % Vectorized
            out_frame = uint8(reshape(out_pix_vect,size(in_frame)));
            release(MYFIL);
            
        otherwise
            disp ('Undefined Simulation mode !')
            return;
    end
    
    % Frame Display
    subplot(1,2,1); imagesc(in_frame); title('source'); colormap('gray'); axis image; axis off;
    subplot(1,2,2); imagesc(out_frame); title('processed');  colormap('gray'); axis image; axis off;
    
    %     sF = 1.3; % scale factor
    %     hAx = findobj(f, 'type', 'axes');
    %     for h = 1:length(hAx)
    %         currPos = get(hAx(h), 'Position'); % current position
    %         set(hAx(h), 'Position', (currPos.*[1 1 sF sF])-[currPos(3)*(sF-1)/2 currPos(4)*(sF-1)/2 0 0]);
    %     end
end
toc