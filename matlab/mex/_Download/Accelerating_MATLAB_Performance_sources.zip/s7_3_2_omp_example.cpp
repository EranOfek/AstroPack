// �7.3.2 - binomial coefficients computation using MEX, OpenMP and the GMP library
#include <mex.h>
#include <omp.h>
#include <gmp.h>

/* parallel compute function */ 
void do_calculation(unsigned *g_in, mxArray *g_out, unsigned n_thids)
{
    // start parallel section with n_thids threads
    #pragma omp parallel num_threads(n_thids)
    {
        int tid = omp_get_thread_num();
        long tid = (long)t;          // get this thread's ID
        unsigned *in = g_in + tid*2; // and the inputs 'n' and 'k'
        mpz_t z;                 // initialize a GMP large integer
        mpz_init(z);

        // calculate binomial coefficient
        mpz_bin_uiui(z, (unsigned long)in[0], (unsigned long)in[1]);

        // estimate the size of the result (in 32-bit words)
        unsigned numb = sizeof(unsigned)*8;
        unsigned n_limbs = (mpz_sizeinbase(z, 2) + numb-1) / numb;
        mxArray *res = mxCreateNumericMatrix(n_limbs, 1,
                                           mxUINT32_CLASS, mxREAL);

        // copy 32-bit words (limbs) to the output vector
        mpz_export(mxGetData(res), NULL, 1, sizeof(unsigned),0,0,z);
        
        // protect access to g_out with critical section
        #pragma omp critical
        {
            mxSetCell(g_out, tid, res);
        }
        mpz_clear(z);  // release a large integer and exit
    } // end of parallel section
}

/* The MEX gateway function */
void mexFunction(int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
    // number of threads is determined by the size of the inputs
    mwSize n_thids = mxGetNumberOfElements(prhs[0])/2;
    unsigned *in = (unsigned *)mxGetData(prhs[0]);
    plhs[0] = mxCreateCellMatrix(n_thids, 1);
    mxArray *out = plhs[0];
    do_calculation(in, out, n_thids);
}
