%% �2.3 - A timed logger function
function log(severity,message,varargin)
   message = sprintf(message,varargin{:});
   timeStr = datestr(now,'yyyy-mm-dd HH:MM:SS.fff');
   logFid = fopen('application.log','at');
   fprintf(logFid, '%s  %s\t %s\n', timeStr, severity, message);
   fclose(logFid);
end
