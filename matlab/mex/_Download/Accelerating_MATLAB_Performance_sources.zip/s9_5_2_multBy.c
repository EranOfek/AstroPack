// �9.5.2 - multiply data in-place
#include "mex.h"
void mexFunction(int nlhs,       mxArray *plhs[], 
                 int nrhs, const mxArray *prhs[])
{
    mwSize i, numel;
    double *pr, multiplier;
    if (nrhs != 2 || nlhs != 0) {
        mexErrMsgTxt("Need 2 inputs (data, multiplier) & 0 outputs");
    }

    if (!mxIsDouble(prhs[0]) || !mxIsDouble(prhs[1])) {
        mexErrMsgTxt("Both inputs must be double");
    }
    
    if (mxIsSparse(prhs[0])) {
        numel = *(mxGetJc(prhs[0])+ mxGetN(prhs[0]));
    } else {
        numel = mxGetNumberOfElements(prhs[0]);
    }
    
    pr = mxGetPr(prhs[0]);
    multiplier = mxGetPr(prhs[1]);
    for (i=0; i<numel; i++) {
        pr[i] *= multiplier;
    }
}
