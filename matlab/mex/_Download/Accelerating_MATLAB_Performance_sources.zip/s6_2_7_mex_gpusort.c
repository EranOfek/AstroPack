// �6.2.7 - array sorting using CUDA and the Thrust library
#include "mex.h"
#include "cuda_runtime.h"
#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/sequence.h>
#include <thrust/sort.h>

/* The gateway function */
void mexFunction(int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) {
   if (nrhs != 1)
      mexErrMsgIdAndTxt("MyMEX:gpusort:nrhs", "One input required");

   if (!mxIsDouble(prhs[0]))
      mexErrMsgIdAndTxt("MyMEX:gpusort:nrhs", "Array must be double");

   // obtain pointer to the input array and number of elements
   double *g_in = mxGetPr(prhs[0]);
   size_t numel = mxGetNumberOfElements(prhs[0]);

   // allocate page-locked host memory for zero-memory copy
   double *cpu_ptr, *dev_pinned_ptr;
   cudaHostAlloc(&cpu_ptr, numel*sizeof(double), cudaHostAllocMapped);
   cudaHostGetDevicePointer(&dev_pinned_ptr, cpu_ptr, 0);

   // copy data from the input array
   memcpy(cpu_ptr, g_in, numel*sizeof(double));

   // init thrust pointer to device memory
   thrust::device_ptr<double> d_vec = 
        thrust::device_pointer_cast(dev_pinned_ptr); 

   // sort the vector on the GPU and wait for completion
   thrust::sort(d_vec, d_vec + numel); 
   cudaThreadSynchronize();

   // create the output matrix and obtain the pointer
   plhs[0] = mxCreateDoubleMatrix((mwSize)numel, 1, mxREAL);
   double *g_out = mxGetPr(plhs[0]);

   // copy the results from the GPU
   memcpy(g_out, cpu_ptr, numel*sizeof(double));
   cudaFreeHost(cpu_ptr);
}
