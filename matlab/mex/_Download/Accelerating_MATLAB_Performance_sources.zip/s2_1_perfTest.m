%% �2.1.2 - A sample profiling session
function perfTest
    newData = subFunc();
    maxData = max(max(newData));
    result = maxData + rand(1,1000000);
    disp(max(result));
end  % perfTest 

function result = subFunc()
    persistent fileData
    if isempty(fileData)
        fileData = load('data.mat');
    end
    result = sin(fileData.data);
end  % subFunc


% Original (unoptimized) version:
%{
function perfTest
    for iter = 1 : 100
        newData = subFunc(iter);
        result(iter) = max(max(newData)) + rand(1);
    end
    disp(max(result));
end  % perfTest

function result = subFunc(iteration)
    fileData = load('data.mat');
    result = sin(fileData.data);
end  % subFunc
%}
