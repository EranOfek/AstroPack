// �8.2.2 - generateDistanceMatrix Coder-generated C-function

/*
 * generateDistanceMatrix.c
 *
 * Code generation for function 'generateDistanceMatrix'
 *
 * C source code generated on: Sun Jul 21 00:02:57 2013
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "generateDistanceMatrix.h"
#include "generateDistanceMatrix_emxutil.h"

/* Function Definitions */
void generateDistanceMatrix(const emxArray_real_T *A, const emxArray_real_T *B,
  emxArray_real_T *r)
{
  int A_idx_0;
  int i0;
  int idxA;
  int idxB;
  double coordDiff[3];
  double y[3];
  double b_y;

  /*  # of points (rows) in A */
  /*  # of points (rows) in B */
  A_idx_0 = A->size[0];
  i0 = r->size[0] * r->size[1];
  r->size[0] = A_idx_0;
  emxEnsureCapacity((emxArray__common *)r, i0, (int)sizeof(double));
  A_idx_0 = B->size[0];
  i0 = r->size[0] * r->size[1];
  r->size[1] = A_idx_0;
  emxEnsureCapacity((emxArray__common *)r, i0, (int)sizeof(double));
  A_idx_0 = A->size[0] * B->size[0];
  for (i0 = 0; i0 < A_idx_0; i0++) {
    r->data[i0] = 0.0;
  }

  for (idxA = 0; idxA < A->size[0]; idxA++) {
    for (idxB = 0; idxB < B->size[0]; idxB++) {
      for (i0 = 0; i0 < 3; i0++) {
        coordDiff[i0] = A->data[idxA + A->size[0] * i0] - B->data[idxB + B->
          size[0] * i0];
      }

      /*  3-element array */
      for (A_idx_0 = 0; A_idx_0 < 3; A_idx_0++) {
        y[A_idx_0] = coordDiff[A_idx_0] * coordDiff[A_idx_0];
      }

      b_y = y[0];
      for (A_idx_0 = 0; A_idx_0 < 2; A_idx_0++) {
        b_y += y[A_idx_0 + 1];
      }

      r->data[idxA + r->size[0] * idxB] = sqrt(b_y);
    }
  }
}

/* End of code generation (generateDistanceMatrix.c) */
