// �11.7 - C-MEX example of writing a data array to file
#include <stdio.h>
#include <string.h>
#include "mex.h"

void mexFunction(int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
    FILE *fp = NULL;
    char *filename = NULL;
    char *str = NULL;
    size_t numElementsExpected = 0;
    size_t numElementsWritten = 0;
 
    /* Check for proper number of input and output arguments */
    if (nrhs != 2)
        mexErrMsgIdAndTxt("YMA:MexIO:invalidNumInputs",
                "Two input arguments required: filename, data");
    if (nlhs > 1)
        mexErrMsgIdAndTxt("YMA:MexIO:maxlhs",
                "Too many output arguments");
    if (!mxIsChar(prhs[0]))
        mexErrMsgIdAndTxt("YMA:MexIO:invalidInput",
                "Input filename must be of type string");
 
    /* Open the file for binary output */
    filename = mxArrayToString(prhs[0]);
    fp = fopen(filename, "wb");
    if (fp == NULL)
        mexErrMsgIdAndTxt("YMA:MexIO:errorOpeningFile",
                "Could not open file %s", filename);

    /* Write the data to file */
    if (mxIsChar(prhs[1])) {
        str = mxArrayToString(prhs[1]);
        numElementsExpected = strlen(str);
        numElementsWritten = (size_t) fwrite(str, sizeof(char), 
                                             numElementsExpected, fp);
        mxFree(str);
    } else if (mxIsDouble(prhs[1])) {
        numElementsExpected = mxGetNumberOfElements(prhs[1]);
        numElementsWritten = (size_t) fwrite(mxGetPr(prhs[1]), 
                                             sizeof(double),
                                             numElementsExpected, fp);
    }
    fclose(fp);

    /* Ensure that the data was correctly written */
    if (numElementsWritten != numElementsExpected)
        mexErrMsgIdAndTxt("YMA:MexIO:errorWritingFile",
                "Error writing data to %s: wrote %d, expected %d\n", 
                filename, numElementsWritten, numElementsExpected);
 
    /* Return the number of elements written to the caller */
    if (nlhs > 0)
        plhs[0] = mxCreateDoubleScalar(numElementsWritten);
}
