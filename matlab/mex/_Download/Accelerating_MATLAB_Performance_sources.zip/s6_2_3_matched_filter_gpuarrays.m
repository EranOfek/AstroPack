%% �6.2.3 - version of the matched filter function using GPU arrays
function data = matched_filter_gpuarrays(data)

   % define speed of light
   c = 299792458;

   % determine the size of the phase history data
   K  = size(data.phdata,1); % number of frequency bins per pulse
   Np = size(data.phdata,2); % number of pulses

   % transfer data to the GPU
   minF   = gpuArray(data.minF); 
   AntX   = gpuArray(data.AntX);
   AntY   = gpuArray(data.AntY); 
   AntZ   = gpuArray(data.AntZ);
   R0     = gpuArray(data.R0);
   phdata = gpuArray(data.phdata);
   deltaF = gpuArray(data.deltaF);

   % initialize the image slices with all zero values
   im_slices = gpuArray.zeros([K size(data.x_mat)], 'double');

   % loop through every pulse
   for ii = 1:Np

      % Calculate differential range for each image pixel (m)
      ax = bsxfun(@minus,AntX(ii),data.x_mat);
      ay = bsxfun(@minus,AntY(ii),data.y_mat);
      az = bsxfun(@minus,AntZ(ii),data.z_mat);

      % computes sqrt(ax^2 + ay^2 + az^2)
      dR = bsxfun(@hypot, ax + 1i*ay, az) - R0(ii);

      % Calculate the frequency of each sample in the pulse (Hz)
      freq = minF(ii) + 0 : deltaF : deltaF*(K-1);

      % Perform the Matched Filter operation
      dR = reshape(dR, [1 size(dR)]); 
      dR = repmat(dR, K, 1);  % replicate data for bsxfun
      t = exp(1i*4*pi/c*bsxfun(@times, freq', dR));
      im_slices = im_slices + bsxfun(@times, phdata(:,ii), t);
   end  % for ii = 1:Np

   % sum up image slices and copy the results back to CPU
   data.im_final = gather(squeeze(sum(im_slices,1)));

end  % matched_filter_gpuarrays
