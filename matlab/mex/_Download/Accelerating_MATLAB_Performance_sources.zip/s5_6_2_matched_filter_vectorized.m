%% �5.6.2 - vectorized version of the matched filter function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by LeRoy Gorham, Air Force Research Laboratory, WPAFB, OH
% Email: leroy.gorham@wpafb.af.mil
% Date Released: 8 Apr 2010
% Gorham, L.A. and Moore, L.J., "SAR image formation toolbox for
% MATLAB", Algorithms for Synthetic Aperture Radar Imagery XVII
% 7669, SPIE (2010).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function data = matched_filter_vectorized(data)

    % define speed of light
    c = 299792458;

    % determine the size of the phase history data
    K  = size(data.phdata,1); % number of frequency bins per pulse
    Np = size(data.phdata,2); % number of pulses

    % initialize the image with all zero values
    data.im_final = zeros(size(data.x_mat), 'double');

    % loop through every pulse
    for ii = 1 : Np

        % Calculate differential range for each image pixel (m)
        dR = sqrt((data.AntX(ii)-data.x_mat).^2 + ...
                  (data.AntY(ii)-data.y_mat).^2 + ...
                  (data.AntZ(ii)-data.z_mat).^2) - data.R0(ii);

        % Calculate the frequency of each sample in the pulse (Hz)
        freq = data.minF(ii) + (0:(K-1)) * data.deltaF;

        % Perform the Matched Filter operation
        for jj = 1 : K
            data.im_final = data.im_final + ... 
                     data.phdata(jj,ii) * exp(1i*4*pi*freq(jj)/c*dR);
        end

    end % for ii = 1:Np

end  % matched_filter_vectorized
