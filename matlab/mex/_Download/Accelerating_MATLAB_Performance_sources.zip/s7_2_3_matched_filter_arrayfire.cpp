// �7.2.3 - version of the matched filter function using ArrayFire library
#include <cuda.h>
#include <arrayfire.h>
#include <mex.h>

// matched filter realization using ArrayFire
void matched_filter_ArrayFire(SAR_data& data) {
   double c = 299792458.0; // speed of light

   // Determine the size of the phase history data
   int K  = data.phdata.dims(0);  // # of frequency bins per pulse
   int Np = data.phdata.dims(1);  // # of pulses

   // Initialize the image with all zero values (complex)
   data.im_final = zeros(data.x_mat.dims(), c64);
   array im_slices = zeros(K, data.x_mat.dims(0),
                              data.x_mat.dims(1), c64);
   array fspan = array(seq(0.0, K-1)) * data.deltaF;

   for (int ii = 0; ii < Np; ii++) {
      // compute differential range for each image pixel (m)
      array dx = data.AntX(ii) - data.x_mat;
      array dy = data.AntY(ii) - data.y_mat;
      array dz = data.AntZ(ii) - data.z_mat;
      array dR = sqrt(dx*dx + dy*dy + dz*dz) - data.R0(ii);

      // calculate the frequency of each sample in the pulse (Hz)
      array freq = data.minF(ii) + fspan;
      array tt = data.phdata(span,ii);
      
      // perform the Matched Filter operation
      gfor (array jj, K) {
         im_slices(jj,span,span) = 
            tt(jj)*exp(i*((double)(4.0*Pi/c)*freq(jj)*dR)); 
      }
      tt = sum(im_slices,0);
      data.im_final = data.im_final + reshape(tt, data.x_mat.dims());
   }
}

// initializes an GPU array from a given data field
void init_field(array& out, const mxArray *rhs, 
                const char *field_name, bool is_complex = false) {
   mxArray *mxA = mxGetField(rhs, 0, field_name);
   const mwSize *dims = mxGetDimensions(mxA);
   array re(dims[0], dims[1], mxGetPr(mxA), afHost);
   if (!is_complex) {
      out = re;
   } else {
      // construct an array of complex data on the GPU
      array im(dims[0], dims[1], mxGetPi(mxA), afHost);
      out = complex(re, im);  
   }
}

// the MEX gateway function
void mexFunction(int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) {
   SAR_data data; // initialize the data structure
   init_field(data.x_mat, prhs[0], "x_mat");
   init_field(data.y_mat, prhs[0], "y_mat");
   init_field(data.z_mat, prhs[0], "z_mat");
   init_field(data.AntX,  prhs[0], "AntX");
   init_field(data.AntY,  prhs[0], "AntY");
   init_field(data.AntZ,  prhs[0], "AntZ");
   init_field(data.minF,  prhs[0], "minF");
   init_field(data.R0,    prhs[0], "R0");
   init_field(data.phdata, prhs[0], "phdata", true);
   data.deltaF = mxGetScalar(mxGetField(prhs[0], 0, "deltaF"));
   
   // invoke the algorithm
   matched_filter_ArrayFire(data);
   int sx = data.im_final.dims(0);
   int sy = data.im_final.dims(1);
   
   // create the output data matrix
   plhs[0] = mxCreateNumericMatrix(sx, sy, mxDOUBLE_CLASS, mxCOMPLEX);
   
   // copy the results from im_final field
   double *pre = af::real(data.im_final).host<double>();
   memcpy(mxGetPr(plhs[0]), pre, sx*sy*sizeof(double));
   double *pim = af::imag(data.im_final).host<double>();
   memcpy(mxGetPi(plhs[0]), pim, sx*sy*sizeof(double));
   array::free(pre);  // free temporary storage
   array::free(pim);
}
