%% �6.3.3 - A sample job submission function
function mysubmitfunc(cluster, job, props)
    
    % values to be sent to the MATLAB workers
    decodeFcn = 'mydecodefunc';
    jobLocation        = get(props, 'JobLocation');
    taskLocations      = get(props, 'TaskLocations');  % a cell array
    storageLocation    = get(props, 'StorageLocation');
    storageConstructor = get(props, 'StorageConstructor');
    
    % set the corresponding environment variables
    setenv('MDCE_DECODE_FUNCTION',     decodeFcn);
    setenv('MDCE_JOB_LOCATION',        jobLocation);
    setenv('MDCE_STORAGE_LOCATION',    storageLocation);
    setenv('MDCE_STORAGE_CONSTRUCTOR', storageConstructor);

    % set the task-specific variables and scheduler commands
    for i = 1 : props.NumberOfTasks
        setenv('MDCE_TASK_LOCATION', taskLocations{i});

        % the code to execute scheduler's submit command
        constructSchedulerCommand();
    end
end  % mysubmitfunc
