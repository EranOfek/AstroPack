%% �3.7 - Wait for data updates to complete
% (isDone = false if timeout, true if data ok)
function isDone = waitForDone(object, timeout, propName, propValue)

    % Initialize: timeout flag = false
    set(object,propName,propValue);

    % Create and start the separate single-shot timeout timer thread
    hTimer = timer('TimerFcn',@(h,e)set(object,propName,propValue),...
                   'StartDelay',timeout);
    start(hTimer);
    
    % Wait for the object property to change or for timeout,
    % whichever comes first
    waitfor(object, propName, propValue);
    
    % waitfor is over because of timeout or because the data changed.
    % To determine which, check whether timer callback was activated
    isDone = (hTimer.TasksExecuted == 0);
    
    % Delete the time object
    try stop(hTimer);   catch, end
    try delete(hTimer); catch, end
    
    % Return the flag indicating whether or not timeout was reached

end  % waitForDone
