%% �6.1.7 - spmd'ed version of the matched filter function
function data = matched_filter_spmd(data)

   % define speed of light
   c = 299792458;

   % determine the size of the phase history data
   K  = size(data.phdata,1);  % number of frequency bins per pulse
   Np = size(data.phdata,2);  % number of pulses

   % create distributed arrays from local data
   minF   = distributed(data.minF);
   AntX   = distributed(data.AntX);
   AntY   = distributed(data.AntY); 
   AntZ   = distributed(data.AntZ);
   R0     = distributed(data.R0);
   phdata = distributed(data.phdata);

   spmd  % start parallel execution

       im_slices = zeros(size(data.x_mat), 'double');

      % Loop through every pulse
      for ii = drange(1:Np)  % distributed range !
         % Calculate differential range for each image pixel (m)
         dR = sqrt((AntX(ii)-data.x_mat).^2 + ...
                   (AntY(ii)-data.y_mat).^2 + ...
                   (AntZ(ii)-data.z_mat).^2) - R0(ii);

         % Calculate the frequency of each sample in the pulse (Hz)
         freq = minF(ii) + (0:(K-1)) * data.deltaF;

         % Perform the Matched Filter operation
         for jj = 1:K
            im_slices = im_slices + phdata(jj,ii) * ...
                                    exp(1i*4*pi*freq(jj)/c*dR);
         end
      end
   end  % spmd

   % assemble the final image from "slices"
   data.im_final = zeros(size(data.x_mat), 'double');
   for ii = 1:numel(im_slices)
      data.im_final = data.im_final + im_slices{ii};
   end
   
end  % matched_filter_spmd
