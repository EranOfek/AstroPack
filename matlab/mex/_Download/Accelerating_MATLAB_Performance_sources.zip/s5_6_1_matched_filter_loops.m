%% �5.6.1 - loopped version of the matched filter function
function data = matched_filter_loops(data)

    % define speed of light
    c = 299792458;

    % determine the size of the phase history data
    K  = size(data.phdata,1);  % number of frequency bins per pulse
    Np = size(data.phdata,2);  % number of pulses
    
    % initialize the image with all zero values
    data.im_final = zeros(size(data.x_mat));
    
    % loop through every pulse
    for ii = 1 : Np
    
        % get antenna location/distance to scene center for this pulse
        AntX = data.AntX(ii); AntY = data.AntY(ii); 
        AntZ = data.AntZ(ii); R0 = data.R0(ii);
        
        % loop through all pixels of an image
        for j1 = 1 : size(data.x_mat,1)

            for j2 = 1 : size(data.x_mat,2)
        
                % calculate differential range for each image pixel
                dR = sqrt((AntX-data.x_mat(j1,j2))^2 + ...
                          (AntY-data.y_mat(j1,j2))^2 + ...
                          (AntZ-data.z_mat(j1,j2))^2) - R0;

                % accumulate frequency samples for each pixel
                pix = 0;
                
                % start from the minimum frequency for this pulse
                freq = data.minF(ii);
                
                % perform the Matched filter operation
                for jj = 1 : K
                    phdata = data.phdata(jj,ii);
                    pix = pix + phdata * exp(1i*4*pi*freq/c*dR);
                    freq = freq + data.deltaF;
                end
                
                % update the pixel value
                data.im_final(j1,j2) = data.im_final(j1,j2) + pix;

            end % for j2
        end % for j1
    end % for ii = 1:Np

end  % matched_filter_loops
