// �9.5.2 - display info on a shared data copy
#include "mex.h"

/* Add this declaration: it does not exist in the "mex.h" header */
extern mxArray *mxCreateSharedDataCopy(const mxArray *pr);

void mexFunction(int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
    mxArray *copy1 = NULL;
    mxArray *copy2 = NULL;

    /* Check for proper number of input and output arguments */
    if (nrhs != 1)
        mexErrMsgTxt("One input argument required.");
    if (nlhs > 1)
        mexErrMsgTxt("Too many output arguments.");
    
    /* First make a regular deep copy of the input array */
    copy1 = mxDuplicateArray(prhs[0]);
    
    /* Then make a shared copy of the new array */
    copy2 = mxCreateSharedDataCopy(copy1);
    
    /* Print some information about the arrays */
    mexPrintf("Created shared data copy, and regular deep copy\n");
    mexPrintf("prhs[0] = %X, mxGetPr = %X, value = %lf\n",
               prhs[0], mxGetPr(prhs[0]), *mxGetPr(prhs[0]));
    mexPrintf("copy1   = %X, mxGetPr = %X, value = %lf\n", 
               copy1, mxGetPr(copy1), *mxGetPr(copy1));
    mexPrintf("copy2   = %X, mxGetPr = %X, value = %lf\n",
               copy2, mxGetPr(copy2), *mxGetPr(copy2));
    
    /* Destroy the first copy */
    mxDestroyArray(copy1);
    copy1 = NULL;
    mexPrintf("\nFreed copy1\n");
    
    /* copy2 will still be valid */
    mexPrintf("copy2 = %X, mxGetPr = %X, value = %lf\n",
               copy2, mxGetPr(copy2), *mxGetPr(copy2));
}
