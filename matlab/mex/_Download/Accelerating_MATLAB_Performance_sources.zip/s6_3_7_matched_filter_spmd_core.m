%% �6.3.7 - core algorithm of the matched filter function
function data = matched_filter_spmd_core(data)

    % Define speed of light
    c = 299792458;

    % Determine the size of the phase history data
    K  = size(data.phdata,1);  % number of frequency bins per pulse
    Np = size(data.phdata,2);  % number of pulses

    % Create an output "image slice" for each worker
    im_slices = zeros(size(data.x_mat), 'double');

    % Loop through every pulse
    for ii = drange(1:Np)
        % Calculate differential range for each image pixel (m)
        dR = sqrt((AntX(ii)-data.x_mat).^2 + ...
                  (AntY(ii)-data.y_mat).^2 + ...
                  (AntZ(ii)-data.z_mat).^2) - R0(ii);

        % Calculate the frequency of each sample in the pulse (Hz)
        freq = minF(ii) + (0:(K-1)) * data.deltaF;

        % Perform the Matched Filter operation
        for jj = 1 : K
            im_slices = im_slices + phdata(jj,ii) * ...
                        exp(1i*4*pi*freq(jj)/c*dR);
        end
    end
    im_final = im_slices;  % save the computed "image slice"

end  % matched_filter_spmd_core
