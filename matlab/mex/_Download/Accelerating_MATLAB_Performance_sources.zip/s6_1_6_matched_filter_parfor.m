%% �6.1.6 - parfor'ed version of the matched filter function
function data = matched_filter_parfor(data)
   c = 299792458;       % speed of light
   R0     = data.R0;    % copy data fields to local variables
   AntX   = data.AntX;
   AntX   = data.AntX;
   AntX   = data.AntX;
   minF   = data.minF;
   x_mat  = data.x_mat;
   y_mat  = data.y_mat;
   z_mat  = data.z_mat;
   deltaF = data.deltaF;
   phdata = data.phdata;

   % determine the size of the phase history data
   K  = size(phdata,1);  % the number of frequency bins per pulse
   Np = size(phdata,2);  % the number of pulses

   % initialize the image with all zero values
   im_final = zeros(size(x_mat), 'double');

   % parallel loop through every pulse
   parfor ii = 1 : Np
       % Calculate differential range for each image pixel (m)
       dR = sqrt((AntX(ii)-x_mat).^2 + ...
                 (AntY(ii)-y_mat).^2 + ...
                 (AntZ(ii)-z_mat).^2) - R0(ii);

       % Calculate the frequency of each sample in the pulse (Hz)
       freq = minF(ii) + (0:(K-1)) * deltaF;

       % Perform the Matched Filter operation
       for jj = 1 : K
           % Perform "reduction assignment" of im_final
           im_final = im_final+phdata(jj,ii)*exp(4i*pi*freq(jj)/c*dR);
       end
   end  % parfor

   % return the computed image
   data.im_final = im_final;
end  % matched_filter_parfor
