// �7.3.1 - binomial coefficients computation using MEX, pthreads and the GMP library
#include "mex.h"
#include <pthread.h>
#include <iostream.h>
#include <vector.h>
#include <stdlib.h>
#include <gmp.h>

unsigned *g_in;  // input parameters
mxArray *g_out;  // output cell array
pthread_mutex_t mex_mtx;

/* thread compute function */ 
void *thread_compute(void *t)
{
   long tid = (long)t;          // get this thread's ID
   unsigned *in = g_in + tid*2; // and the inputs 'n' and 'k'
   mpz_t z;                     // initialize a GMP large integer
   mpz_init(z);

   // calculate binomial coefficient
   mpz_bin_uiui(z, (unsigned long)in[0], (unsigned long)in[1]);

   // estimate the size of the result (in 32-bit words)
   unsigned numb = sizeof(unsigned)*8;
   unsigned n_limbs = (mpz_sizeinbase(z,2) + numb-1) / numb;
   mxArray *res = mxCreateNumericMatrix(n_limbs, 1,
                                        mxUINT32_CLASS, mxREAL);

   // copy 32-bit words (limbs) to the output vector
   mpz_export(mxGetData(res), NULL, 1, sizeof(unsigned), 0, 0, z);

   // lock mutex and copy the result to the cell array
   pthread_mutex_lock(&mex_mtx);
   mxSetCell(g_out, tid, res);
   pthread_mutex_unlock(&mex_mtx);
   mpz_clear(z);       // release the large GMP integer and exit
   pthread_exit(NULL);
}

/* The MEX gateway function */
void mexFunction(int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) {
   // number of threads is determined by the size of the inputs
   pthread_mutex_init(&mex_mtx, NULL);
   mwSize n_thids = mxGetNumberOfElements(prhs[0])/2;
   g_in = (unsigned *)mxGetData(prhs[0]);
   plhs[0] = mxCreateCellMatrix(n_thids, 1);
   g_out = plhs[0];
   std::vector< pthread_t > threads(n_thids);
   pthread_attr_t attr;

   // create attributes for joinable threads
   pthread_attr_init(&attr);
   pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
   
   // launch the threads
   for (int i = 0; i < n_thids; i++) {
      pthread_create(&threads[i], &attr, thread_compute, (void *)i);
   }

   // wait until all threads finish processing
   for (int i = 0; i < n_thids; i++) {
      pthread_join(threads[i], NULL);
   }
   pthread_attr_destroy(&attr);
   pthread_mutex_destroy(&mex_mtx);
}
