%% �9.5.3 - Singleton class implementation

% Concrete singleton implementation
classdef Singleton < handle
    properties (Access=private)
        data
    end  % private properties

    methods (Access=private)
        % The constructor is private, preventing external invocation.
        % Only a single instance of this class is created. This is
        % ensured by getInstance() calling the constructor only once.
        function newObj = Singleton()
            % Initialize - maybe load from disk?
        end  % constructor
    end  % private methods
    
    methods (Static)
        function setData(newData)
            obj = getInstance();
            obj.data = newData;
        end  % setData()
        function data = getData()
            obj = getInstance();
            data = obj.data;
        end  % getData()
    end  % static methods
end  % classdef

% Note: this is deliberately placed *outside* the class, so that it
% ^^^^  is not exposed to the user. If we do not mind this, we could
%       place getInstance() in the class's static methods group.
function obj = getInstance()
    persistent uniqueInstance
    if isempty(uniqueInstance)
        obj = Singleton();
        uniqueInstance = obj;
    else
        obj = uniqueInstance;
    end
end  % getInstance()
