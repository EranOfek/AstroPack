%% �6.3.7 - distributed version of the matched filter function
function data = matched_filter_mpiexec(data)

   % create the cluster object
   cl = parallel.cluster.Mpiexec;

   % create a communicating job of type "spmd"
   j = createCommunicatingJob(cl,'Type','spmd');

   % set the number of workers for this job
   j.NumWorkersRange = [1 20];

   % create a new task 
   createTask(j, @matched_filter_spmd_core, 1, {data});

   % submit the job and wait for completion 
   submit(j);
   wait(j);

   % fetch the results and delete the job
   out = fetchOutputs(j);
   delete(j);

   % assemble the final image from parts computed by the workers
   data.im_final = zeros(size(data.x_mat));
   for ii = 1 : numel(out)
       data.im_final = data.im_final + out{ii};
   end

end  % matched_filter_mpiexec
