%% �6.3.3 - A sample worker decode function
function props = workerDecodeFunc(props)
    
    % Read the environment variables:
    storageConstructor = getenv('MDCE_STORAGE_CONSTRUCTOR');
    storageLocation    = getenv('MDCE_STORAGE_LOCATION');
    jobLocation        = getenv('MDCE_JOB_LOCATION');
    taskLocation       = getenv('MDCE_TASK_LOCATION');
   
    % Set props object properties from the local variables:
    set(props, 'StorageConstructor', storageConstructor);
    set(props, 'StorageLocation',    storageLocation);
    set(props, 'JobLocation',        jobLocation);
    set(props, 'TaskLocation',       taskLocation);
end  % workerDecodeFunc
