%% �6.1.2 - Reorder the elements of an array in parallel
function out = shift_array(N)
    spmd
        if labindex == 1
            % generate & send the sequence 1..N to all workers
            A = labBroadcast(1,1:N); 
        else
            % receive data on other workers
            A = labBroadcast(1);
        end

        % get an array chunk on each worker
        I = find(A > N*(labindex-1)/numlabs & ...
                 A <= N*labindex/numlabs);

        % shift the data to the right among all workers
        to   = mod(labindex,   numlabs) + 1;  % one to the right
        from = mod(labindex-2, numlabs) + 1;  % one to the left
        I = labSendReceive(labTo, labFrom, I);

        % reconstruct the shifted array on the first worker
        out = gcat(I, 2, 1);
    end
end  % shift_array
