%% �3.2.5 - Faster variant of datestr, for integer date values since 1/1/2000
function dateStrs = datestr2(dateVals,varargin)
    persistent dateValsCache
    persistent dateStrsCache
    persistent cachedVarargin
    if isempty(dateStrsCache)
        origin = datenum('1-Jan-2000');
        dateValsCache = origin:(now+100); %also cache 100 future dates
        dateStrsCache = datestr(dateValsCache,varargin{:});
        cachedVarargin = varargin;
    end
    [tf,loc] = ismember(dateVals, dateValsCache);
    if all(tf) && isequal(varargin, cachedVarargin)
        dateStrs = dateStrsCache(loc,:);
    else
        dateStrs = datestr(dateVals,varargin{:});
    end
end  % datestr2
