%% �7.1.7 - version of the matched filter function using Jacket gfor loops
function data = matched_filter_gcompile(data)

    % define speed of light
    c = 299792458;

    % determine the size of the phase history data
    K  = size(data.phdata,1); % number of frequency bins per pulse
    Np = size(data.phdata,2); % number of pulses

    % initialize the image with all zero values (on the GPU)
    data.im_final = gzeros(size(data.x_mat), 'double');

    % compile the algorithm�s inner loop in a single GPU kernel
    mf_gcore = gcompile(verbatim);

    %{
    function im_slice = ff(freq, dR, phdata, im_final, c)
        im_slice =  im_final + phdata * exp(1i*4*pi*freq/c*dR);
    end
    %}

    % loop through every pulse
    for ii = 1 : Np
        % Calculate differential range for each image pixel (m)
        dR = sqrt((data.AntX(ii)-data.x_mat).^2 + ...
                  (data.AntY(ii)-data.y_mat).^2 + ...
                  (data.AntZ(ii)-data.z_mat).^2) - data.R0(ii);

        % Calculate the frequency of each sample in the pulse (Hz)
        freq = data.minF(ii) + gdouble(0:(K-1)) * data.deltaF;

        % Perform the Matched Filter operation
        for jj = 1 : K 
            phdata = gdata.phdata(jj,ii);
            freqj = freq(jj);
            data.im_final = mf_gcore(freqj, dR, phdata, ...
                                     data.im_final, c);
        end
    end  % for ii = 1:Np
    gsync('all');  % ensure that all GPU computations are done

end  % matched_filter_gcompile
