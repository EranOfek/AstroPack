%% �7.1.8 - version of the matched filter function using multiple GPUs
function data = matched_filter_multigpu(data)

    % Define speed of light (m/s)
    c = 299792458;
    
    % Determine the size of the phase history data
    K  = size(data.phdata,1);  % number of frequency bins per pulse
    Np = size(data.phdata,2);  % number of pulses
    gdata.im_final = zeros([size(data.x_mat)], 'double');
    ngpu = getfield(ginfo, 'gpu_count');
    
    % start parallel processing on ngpu labs
    spmd (ngpu)
        % cast data explicitly to the GPU for each worker
        minF   = gdouble(data.minF);
        AntX   = gdouble(data.AntX);
        AntY   = gdouble(data.AntY); 
        AntZ   = gdouble(data.AntZ);
        R0     = gdouble(data.R0);
        phdata = gdouble(data.phdata);
        x_mat  = gdouble(data.x_mat);
        y_mat  = gdouble(data.y_mat);
        z_mat  = gdouble(data.z_mat);
        im_slices = gzeros(size(data.x_mat), 'double');
    
        % Loop through every pulse
        for ii = drange(1:Np)
            % Calculate differential range for each image pixel (m)
            dR = sqrt((AntX(ii)-x_mat).^2 + ...
                      (AntY(ii)-y_mat).^2 + ...
                      (AntZ(ii)-z_mat).^2) - R0(ii);
                  
            % Calculate frequency of each sample in the pulse (Hz)
            freq = minF(ii) + gdouble(0:(K-1)) * data.deltaF;
            
            % Perform the Matched Filter operation
            for jj = 1:K
                im_slices = im_slices + phdata(jj,ii) * ...
                                        exp(1i*4*pi*freq(jj)/c*dR);
            end
        end
    end  % spmd

    % gather results computed by different workers
    gdata.im_final = zeros(size(data.x_mat), 'double');
    for ii = 1:numel(im_slices)
        gdata.im_final = gdata.im_final + double(im_slices{ii});
    end

end  % matched_filter_multigpu
