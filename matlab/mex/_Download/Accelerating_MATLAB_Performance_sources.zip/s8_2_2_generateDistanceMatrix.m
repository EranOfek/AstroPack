%% �8.2.2 - generateDistanceMatrix MATLAB function
function r = generateDistanceMatrix(A,B)
    sizeA = size(A,1);  % # of points (rows) in A
    sizeB = size(B,1);  % # of points (rows) in B
    r = zeros(sizeA,sizeB);
    for idxA = 1 : sizeA
        for idxB = 1 : sizeB
            coordDiff = A(idxA,:) - B(idxB,:);      % 3-element array
            r(idxA,idxB) = sqrt(sum(coordDiff.^2));
        end
    end
end