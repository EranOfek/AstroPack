%% �6.2.6 - version of the matched filter function using GPU arrays with CUDA kernel
function data = matched_filter_gpuarrays_cuda(data)

   % Determine the size of the phase history data
   K  = size(data.phdata,1);  % number of frequency bins per pulse
   Np = size(data.phdata,2);  % number of pulses
   minF   = gpuArray(data.minF);
   AntX   = gpuArray(data.AntX);
   AntY   = gpuArray(data.AntY); 
   AntZ   = gpuArray(data.AntZ);
   R0     = gpuArray(data.R0);
   phdata = gpuArray(data.phdata);
   deltaF = gpuArray(data.deltaF);

   mf_core = parallel.gpu.CUDAKernel('mf_core.ptx', 'mf_core.cu');
   mf_core.ThreadBlockSize = [256, 1, 1];
   
   n_elems = numel(data.x_mat);
   mf_core.GridSize = [ceil(n_elems/mf_core.ThreadBlockSize(1)), K];
   
   data.im_final = gpuArray.zeros(size(data.x_mat), 'double');
   im_slices=complex(gpuArray.zeros([size(data.x_mat) K], 'double'));
   
   for ii = 1 : Np  % Loop through every pulse
      % Calculate differential range for each image pixel (m)
      ax = bsxfun(@minus,AntX(ii),data.x_mat);
      ay = bsxfun(@minus,AntY(ii),data.y_mat);
      az = bsxfun(@minus,AntZ(ii),data.z_mat);
      dR = bsxfun(@hypot, ax + 1i*ay, az) - R0(ii);
      freq = minF(ii) + 0 : deltaF : deltaF*(K-1);
   
      % Perform the Matched Filter operation on the CUDA kernel
      im_slices = feval(mf_core, im_slices, dR, freq, ...
                        phdata(:,ii), n_elems);
      data.im_final = data.im_final + squeeze(sum(im_slices,3));
   end
   data.im_final = gather(data.im_final);

end  % matched_filter_gpuarrays_cuda
