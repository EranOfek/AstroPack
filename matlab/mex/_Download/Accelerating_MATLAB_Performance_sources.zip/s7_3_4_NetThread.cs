// �7.3.4 - C# threads example of writing a data array to file
using System;
using System.IO;
using System.Threading;
namespace My
{
    public class NetThread
    {
        string filename;
        double[] doubleData;
        Thread thread;

        public NetThread(string filename, double[] data)
        {
            this.filename = filename;
            this.doubleData = data;
            thread = new Thread(this.run);
        }

        public void start()
        {
            thread.Start();  // note the capital S in Start()
        }

        private void run()
        {
            try
            {
                BinaryWriter out = new BinaryWriter(
                                   File.Open(filename,FileMode.Create))
                for (int i = 0; i < doubleData.Length; i++)
                {
                    out.Write(doubleData[i]);
                }
                out.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
