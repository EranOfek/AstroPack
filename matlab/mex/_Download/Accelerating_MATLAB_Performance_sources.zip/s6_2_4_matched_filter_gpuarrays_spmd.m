%% �6.2.4 - version of the matched filter function using GPU arrays with spmd
function data = matched_filter_gpuarrays_spmd(data)

   % define speed of light
   c = 299792458;

   % determine the size of the phase history data
   K  = size(data.phdata,1);  % number of frequency bins per pulse
   Np = size(data.phdata,2);  % number of pulses
   chunks = 8;  % partition data in several chunks
   Kc = K / chunks;

   spmd(4)  % launch 4 MATLAB workers
      gpuDevice(labindex);  % set current GPU device to worker's ID

      % transfer data to the GPU
      minF   = gpuArray(data.minF);
      AntX   = gpuArray(data.AntX);
      AntY   = gpuArray(data.AntY);
      AntZ   = gpuArray(data.AntZ);
      R0     = gpuArray(data.R0);
      phdata = gpuArray(data.phdata);
      deltaF = gpuArray(data.deltaF);

      % initialize the image slices with all zero values
      im_slices = gpuArray.zeros([Kc size(data.x_mat)], 'double');

      % loop through every pulse
      for ii = drange(1:Np)

         % Calculate differential range for each image pixel (m)
         ax = bsxfun(@minus,AntX(ii),data.x_mat);
         ay = bsxfun(@minus,AntY(ii),data.y_mat);
         az = bsxfun(@minus,AntZ(ii),data.z_mat);

         % computes sqrt(ax^2 + ay^2 + az^2)
         dR = bsxfun(@hypot, ax + 1i*ay, az) - R0(ii);
         dR = reshape(dR, [1 size(dR)]); 
         dR = repmat(dR, Kc, 1);  % replicate data for bsxfun

         % loop for each chunk of size Kc
         for jj = 0 : Kc : K-Kc

            % Calculate the frequency of each pulse sample (Hz)
            freq = minF(ii) + jj*deltaF + 0:deltaF:deltaF*(Kc-1);

            % Perform the Matched Filter operation
            t = exp(1i*4*pi/c*bsxfun(@times, freq', dR));
            im_slices = im_slices + bsxfun(@times, ...
                        phdata(jj+1:jj+Kc,ii), t);
         end
      end  % for ii = 1:Np

      % sum up image slices and copy the results back to CPU
      im_slices = gather(squeeze(sum(im_slices,1)));

   end  % spmd

   % assemble final image from pieces computed by MATLAB workers
   data.im_final = zeros(size(data.x_mat));
   for ii = 1 : numel(im_slices)
      data.im_final = data.im_final + im_slices{ii};
   end

end  % matched_filter_gpuarrays_spmd
