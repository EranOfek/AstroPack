%
% mexPostgres compilation script
%
% Please adjust location of your postgreSQL libpq include and lib
% directories manually, according to your platform. 
% Note: on Windows platform, 'libpq.lib' is dynamic library. To run the mex,
% the libpq.dll has to be set in the system path or in the current directory
% (libpq.dll usually resides together with libpq.lib in PostgreSQL
% installation directory).
%
% Martin Mityska
% 2015

disp('Compiling mexPostgres.cpp')
if isunix == 1  
    mex mexPostgres.cpp -I/usr/include/postgresql -lpq
end
if ispc == 1 % ispc == 1 means Windows platform
    mex mexPostgres.cpp -I"C:\Program Files\PostgreSQL\9.4\include"  -L"C:\Program Files\PostgreSQL\9.4\lib" "C:\Program Files\PostgreSQL\9.4\lib\libpq.lib"
end 
if ismac == 1
    warning('Compilation not tested on MAC platform.');
end
