/*
 * mexPostgres.cpp
 * PostgreSQL binding for MATLAB
 *
 * This routine provides simple PostgreSQL client functionality for MATLAB.
 * The code is based on libpq - official PostgreSQL C library.
 * 
 * Author:  Martin Mityska  
 *          2015
 *
 */

#define HELP_TEXT_BROADER "          mexPostgres - PostgreSQL binding for MATLAB\n"                                         \
                          "Usage   : mexPostgres(connectString, sqlString)\n"                                               \
                          "Optional: mexPostgres(connectString, sqlString, 'verbose')\n"                                    \
     "Example : mexPostgres('dbname=mydb user=testuser password=123 hostaddr=127.0.0.1', 'SELECT * FROM myTable')\n"        \
     "Note    : The code is based on libpq - official PostgreSQL C library. \n"                                             \
     "Author  : Martin Mityska - 2015 \n\n"                                                                                 \
                                                                                                                            \
     "connectString\n"                                                                                                      \
     "*****************************************************************************************************************\n\n"\
                                                                                                                            \
     "   This part of the help describes 1st parameter = connection string options for C psql library.\n"                   \
     "   For further information, visit official documentation at:\n"                                                       \
     "   http://www.postgresql.org/docs/9.4/static/libpq.html\n"                                                            \
     "   or\n"                                                                                                              \
     "   http://www.postgresql.org/docs \n\n"                                                                               \
     "   The 1st parameter (string) defines a new database connection.\n"                                                   \
     "   The passed string can be empty to use all default parameters, or it can contain one or more\n"                     \
     "   parameter settings separated by whitespace.\n"                                                                     \
     "   Each parameter setting is in the form keyword = value. (To write an empty value or a value\n"                      \
     "   containing spaces, surround it with single quotes, e.g., keyword = 'a value'.\n"                                   \
     "   Spaces around the equal sign are optional.\n"                                                                      \
     "   The currently recognized parameter key words are: \n\n"                                                            \
                                                                                                                            \
     "   host\n"                                                                                                            \
     "   Name of host to connect to. If this begins with a slash, it specifies Unix-domain communication\n"                 \
     "   rather than TCP/IP communication; the value is the name of the directory in which the socket file\n"               \
     "   is stored. The default is to connect to a Unix-domain socket in /tmp. \n\n"                                        \
                                                                                                                            \
     "   hostaddr\n"                                                                                                        \
     "   Numeric IP address of host to connect to. This should be in the standard IPv4 address format,\n"                   \
     "   e.g., 172.28.40.9. If your machine supports IPv6, you can also use those addresses. TCP/IP\n"                      \
     "   communication is always used when a nonempty string is specified for this parameter.\n"                            \
     "   Using hostaddr instead of host allows the application to avoid a host name look-up, which may be\n"                \
     "   important in applications with time constraints. However, Kerberos authentication requires the host name.\n"       \
     "   The following therefore applies: If host is specified without hostaddr, a host name lookup occurs.\n"              \
     "   If hostaddr is specified without host, the value for hostaddr gives the remote address.\n"                         \
     "   When Kerberos is used, a reverse name query occurs to obtain the host name for Kerberos.\n"                        \
     "   If both host and hostaddr are specified, the value for hostaddr gives the remote address;\n"                       \
     "   the value for host is ignored, unless Kerberos is used, in which case that value is \n"                            \
     "   used for Kerberos authentication.\n"                                                                               \
     "   (Note that authentication is likely to fail if libpq is passed a host name that is not \n"                         \
     "   the name of the machine at hostaddr.) Also, host rather than hostaddr is used to identify\n"                       \
     "   the connection in $HOME/.pgpass.\n"                                                                                \
     "   Without either a host name or host address, libpq will connect using a local Unix domain socket. \n\n"             \
                                                                                                                            \
     "   port\n"                                                                                                            \
     "   Port number to connect to at the server host, or socket file name extension for Unix-domain connections. \n\n"     \
                                                                                                                            \
     "   dbname\n"                                                                                                          \
     "   The database name. Defaults to be the same as the user name. \n\n"                                                 \
                                                                                                                            \
     "   user\n"                                                                                                            \
     "   PostgreSQL user name to connect as. \n\n"                                                                          \
                                                                                                                            \
     "   password\n"                                                                                                        \
     "   Password to be used if the server demands password authentication. \n\n"                                           \
                                                                                                                            \
     "   connect_timeout\n"                                                                                                 \
     "   Maximum wait for connection, in seconds (write as a decimal integer string).\n"                                    \
     "   Zero or not specified means wait indefinitely. It is not recommended to use a timeout\n"                           \
     "   of less than 2 seconds. \n\n"                                                                                      \
                                                                                                                            \
     "   options\n"                                                                                                         \
     "   Command-line options to be sent to the server. \n\n"                                                               \
                                                                                                                            \
     "   tty\n"                                                                                                             \
     "   Ignored (formerly, this specified where to send server debug output). \n\n"                                        \
                                                                                                                            \
     "   sslmode\n"                                                                                                         \
     "   This option determines whether or with what priority an SSL connection will be negotiated with the server.\n"      \
     "   There are four modes: disable will attempt only an unencrypted SSL connection; allow will negotiate, trying\n"     \
     "   first a non-SSL connection, then if that fails, trying an SSL connection; prefer (the default) will negotiate,\n"  \
     "   trying first an SSL connection, then if that fails, trying a regular non-SSL connection;\n"                        \
     "   require will try only an SSL connection.\n"                                                                        \
     "   If PostgreSQL is compiled without SSL support, using option require will cause an error, and options allow\n"      \
     "   and prefer will be tolerated but libpq will be unable to negotiate an SSL connection. \n\n"                        \
     "   requiressl\n"                                                                                                      \
     "   This option is deprecated in favor of the sslmode setting.\n"                                                      \
     "   If set to 1, an SSL connection to the server is required (this is equivalent to sslmode require).\n"               \
     "   libpq will then refuse to connect if the server does not accept an SSL connection.\n"                              \
     "   If set to 0 (default), libpq will negotiate the connection type with the server (equivalent to sslmode prefer).\n" \
     "   This option is only available if PostgreSQL is compiled with SSL support. \n\n"                                    \
                                                                                                                            \
     "   service \n"                                                                                                        \
     "   Service name to use for additional parameters. It specifies a service name in pg_service.conf\n"                   \
     "   that holds additional connection parameters.\n"                                                                    \
     "   This allows applications to specify only a service name so connection parameters can be\n"                         \
     "   centrally maintained. See PREFIX/share/pg_service.conf.sample for information on how to set up the file. \n\n"     \
     "   If any parameter is unspecified, then the corresponding environment variable (see PostgreSQL docs) is checked.\n"  \
     "   If the environment variable is not set either, then built-in defaults are used. \n\n"                              \
                                                                                                                            \
     "sqlString\n"                                                                                                          \
     "*****************************************************************************************************************\n\n"\
                                                                                                                            \
     "   The 2nd parameter takes valid SQL statement.\n\n"                                                                  \
                                                                                                                            \
     "*****************************************************************************************************************\n"
      
#include "mex.h"
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>
#include <sstream>
#include "libpq-fe.h"

/* FIELD TYPE (OID) definitions according to POSTGRE SQL source code - src/include/catalog/pg_type.h */

#define 	BOOLOID           16
#define 	BYTEAOID          17
#define 	CHAROID           18
#define 	NAMEOID           19
#define 	INT8OID           20
#define 	INT2OID           21
#define 	INT2VECTOROID     22
#define 	INT4OID           23
#define 	REGPROCOID        24
#define 	TEXTOID           25
#define 	OIDOID            26
#define 	TIDOID            27
#define 	XIDOID            28
#define 	CIDOID            29
#define 	OIDVECTOROID      30
#define 	POINTOID         600
#define 	LSEGOID          601
#define 	PATHOID          602
#define 	BOXOID           603
#define 	POLYGONOID       604
#define 	LINEOID          628
#define 	FLOAT4OID        700
#define 	FLOAT8OID        701
#define 	ABSTIMEOID       702
#define 	RELTIMEOID       703
#define 	TINTERVALOID     704
#define 	UNKNOWNOID       705
#define 	CIRCLEOID        718
#define 	CASHOID          790
#define 	INETOID          869
#define 	CIDROID          650
#define 	BPCHAROID       1042
#define 	VARCHAROID      1043
#define 	DATEOID         1082
#define 	TIMEOID         1083
#define 	TIMESTAMPOID    1114
#define 	TIMESTAMPTZOID  1184
#define 	INTERVALOID     1186
#define 	TIMETZOID       1266
#define 	ZPBITOID        1560
#define 	VARBITOID       1562
#define 	NUMERICOID      1700

using namespace std;

/* program entry point (from MATLAB)
 * nlhs - number of returned elements
 * plhs - array of returned elements
 * nrhs - number of arguments
 * prhs - array of arguments 
 */
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    
    /* PostgreSQL connection main variables. */
	PGconn     		*conn;  		/* Database connection handler */
	PGresult   		*res; 	    	/* Results handler */
	ExecStatusType   resStatus;     /* For checking whether query was successful */
	unsigned int     nResCols;      /* Number of returned fields */
	unsigned int     nResRows;      /* Number of returned fields */
	unsigned int	 iRow;          /* Rows iterator */
	unsigned int	 jCol;          /* Cols iterator */

	char *connectInfoString; 		/* Where we store connection parameters - database name.  */
	char *sqlQueryString;           /* Where we store SQL query delivered from the user. */
    
    vector <string> colsLabelsStringsVector;
    vector <const char*> colsLabelsCStringsPtrVector;
    vector <unsigned int> colsDataTypeVector;
    
    int              verboseFlag = 0;

    /* Printing  broader help text */
    if(nrhs == 1)
    {
        mexPrintf(HELP_TEXT_BROADER);
        
        /* Let's return empty matrix */
        plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
        nlhs    = 1;
        
        return;
    }
    
    /* Checking if there are enough arguments */
    if(nrhs < 2)
    {
        mexErrMsgTxt("Not enough arguments.\n\n" 
                     "Usage   : mexPostgres(connectString, sqlString)\n"
                     "Optional: mexPostgres(connectString, sqlString, 'verbose')\n"
                     "Example : mexPostgres('dbname=mydb user=testuser password=123 hostaddr=127.0.0.1', 'SELECT * FROM myTable');\n"
                     "For more detailed help type: mexPostgres('help')\n\n");
        
        return;
    }
    
    if(nrhs > 2) verboseFlag=1;
    
    /* Number of arguments satisfied. Let's populate connection string and SQL query string.*/
    connectInfoString   = mxArrayToString(prhs[0]);
	sqlQueryString      = mxArrayToString(prhs[1]);

	/* We are connecting database. */
	conn = PQconnectdb(connectInfoString);

	/* Let's check wheteher the connection is open and ready. */
	if(PQstatus(conn)==CONNECTION_BAD)
	{
        stringstream errMsgStream;
        errMsgStream << "ERROR in file " << __FILE__ << " at line " << __LINE__ << endl; 
        errMsgStream << "Database connection failed." << endl;
        errMsgStream << "Connection string:" << endl;
        errMsgStream << connectInfoString << endl;
        errMsgStream << "PostgreSQL error message:" << endl;
        errMsgStream << PQerrorMessage(conn) << endl;
		mexErrMsgTxt(errMsgStream.str().c_str());
		return;
	}

	if(verboseFlag) mexPrintf("%s\n\n",sqlQueryString);

	res = PQexec(conn, sqlQueryString);

	resStatus = PQresultStatus(res);

	if(resStatus == PGRES_BAD_RESPONSE || resStatus == PGRES_FATAL_ERROR)
	{
        stringstream errMsgStream;
        errMsgStream << "ERROR in file " << __FILE__ << " at line " << __LINE__ << endl; 
        errMsgStream << "SQL query failed." << endl;
        errMsgStream << "Query string:" << endl;
        errMsgStream << sqlQueryString << endl;
        errMsgStream << "PostgreSQL error message:" << endl;
        errMsgStream << PQerrorMessage(conn) << endl;
		mexErrMsgTxt(errMsgStream.str().c_str());
        
        /* Let's clear every query. Important because of possible memory leaks. */
		PQclear(res);
        return;
	}

	if(resStatus == PGRES_NONFATAL_ERROR)
	{
        stringstream errMsgStream;
        errMsgStream << "WARNING in file " << __FILE__ << " at line " << __LINE__ << endl; 
        errMsgStream << "SQL query raised NONFATAL_ERROR." << endl;
        errMsgStream << "Query string:" << endl;
        errMsgStream << sqlQueryString << endl;
        errMsgStream << "PostgreSQL error message:" << endl;
        errMsgStream << PQerrorMessage(conn) << endl;
		mexWarnMsgTxt(errMsgStream.str().c_str());
        
	}
   
    /* Getting number of rows and columns of fetched query result. */
	nResRows=PQntuples(res);
	nResCols=PQnfields(res);

	/* If verbose flag is on, printing results overview. */
    if(verboseFlag) 
    {
        mexPrintf("Result overview:\n");
        mexPrintf("Number of cols  : %d\n",nResCols);
        mexPrintf("Number of rows  : %d\n",nResRows);
        mexPrintf("Labels          :\n");
    }
    
    /* In case of no result,... */
    if(nResRows <= 0)
    {
        /* ...let's return an empty matrix. */
        plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
        nlhs    = 1;
        return;
    }

    /* Building result structure. */
    
	for (jCol = 0; jCol < nResCols; jCol++)
	{
            colsLabelsStringsVector.push_back(PQfname(res, jCol));
            colsLabelsCStringsPtrVector.push_back(colsLabelsStringsVector.at(jCol).c_str());
            
            if(verboseFlag) mexPrintf("\t%s\n", PQfname(res, jCol));
            
            colsDataTypeVector.push_back(PQftype(res,jCol));
            
            /* Checking whether data types are supported. Decoder will try to decode unsupported data as string. */
            switch(colsDataTypeVector.at(jCol))
            {
                case TEXTOID:
                case CHAROID:
                    /* TEXT DATA TYPES */
                    break;
                case BOOLOID:
                case FLOAT4OID:
                case FLOAT8OID:
                case INT8OID:
                case INT4OID:
                case INT2OID:
                case NUMERICOID:
                    /* NUMERICAL DATA TYPES */
                    break;
                case DATEOID:
                case TIMEOID:
                case TIMESTAMPOID:
                case INTERVALOID:
                case TIMESTAMPTZOID:
                case TIMETZOID:
                    /* TIME DATA TYPES */
                    /* Date/Time entries are returned as strings. */
                    break;
                default:
                   stringstream errMsgStream;   
                   errMsgStream << "WARNING - unsupported field data type (OID) " << colsDataTypeVector.at(jCol) << ". Trying to encode as string" << endl; 
                   mexWarnMsgTxt(errMsgStream.str().c_str()); 
            }
	}
    
	if(verboseFlag) mexPrintf("\n\n");
    
    /* Creating result struct. If there is not enough memory, the MATLAB will terminate mex automatically. */
    plhs[0] = mxCreateStructMatrix(nResRows, 1, nResCols, &colsLabelsCStringsPtrVector[0]);
    /* Setting number of returned fields to 1 */
	nlhs = 1;

	/* Let's populate struct with all rows.*/
	for (iRow = 0; iRow <nResRows; iRow++)
	{
		for (jCol = 0; jCol < nResCols; jCol++)
        {
            switch(colsDataTypeVector.at(jCol))
            {
                case BOOLOID:
                case FLOAT4OID:
                case FLOAT8OID:
                case INT8OID:
                case INT4OID:
                case INT2OID:
                case NUMERICOID:
                    mxSetField(plhs[0], iRow, colsLabelsCStringsPtrVector.at(jCol), mxCreateDoubleScalar(atof(PQgetvalue(res, iRow, jCol))));
                    break;
                case DATEOID:
                case TIMEOID:
                case TIMESTAMPOID:
                case INTERVALOID:
                case TIMESTAMPTZOID:
                case TIMETZOID:
                    /* Date/Time entries are returned as strings. */
                    mxSetField(plhs[0], iRow, colsLabelsCStringsPtrVector.at(jCol), mxCreateString(PQgetvalue(res, iRow, jCol)));
                    break;
                default:
                    mxSetField(plhs[0], iRow, colsLabelsCStringsPtrVector.at(jCol), mxCreateString(PQgetvalue(res, iRow, jCol)));
                    
            }
            
          /* Optional for printing raw results as strings.      */  
          /* mexPrintf("%-15s", PQgetvalue(res, iRow, jCol));   */
            
        }
		
	}
    
    /* Clearing query heap. */
	PQclear(res);

    /* Closing connection. */
	PQfinish(conn);

}
