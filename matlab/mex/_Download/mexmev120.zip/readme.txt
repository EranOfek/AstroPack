mexme - Write MEX files in no time

Open TestMexMe.m in cell mode and read through the examples to learn how to use.

History:

v1.2.0 - 11-11-2012 - Implemented Jan Simon's suggestions - now compatible with Windows (VSCC)
v1.1.0 - 09-05-2011 - Added input validation
v1.0.1 - 02-05-2011 - TestMexMe.m included in zip file (oops)
v1.0.0 - 30-04-2011 - Initial release

Author:
Patrick Mineault
patrick DOT mineault AT gmail DOT com
Comments welcome
